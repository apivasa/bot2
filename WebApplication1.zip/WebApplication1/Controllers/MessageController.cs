﻿using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using TweetSharp;

namespace WebApplication1.Controllers
{
    [BotAuthentication]
    public class MessageController : ApiController
    {
        private static string customer_key = "XA0xhlSQ6TON3bNZV05yQTlpg";
        private static string customer_key_secret = "lrnuBKfAGbOD8PQjnjBFKy0CtV0Jdas4zZwBSxWp7h5fn2YmFk";
        private static string access_token = "94697751-cVe9TX9MRhfLeR8v7xBmVlUpWRcsypy1fpqCHWHi3";
        private static string access_token_secret = "ZC2nPOIPogTVGT3qQNw53T8nCKpMZ8WhhhHhhWCxjnF5n";

        private static TwitterService service = new TwitterService(customer_key, customer_key_secret, access_token, access_token_secret);

        public async Task<HttpResponseMessage> Post([FromBody]Activity activity)
        {
            if (activity.Type == ActivityTypes.Message)
            {
                Activity reply = null;
                var mensaje = activity.Text.ToLower();
                String subMensaje = mensaje.Substring(0, 4);
                var tmensaje = activity.Text;
                String tw = tmensaje.Remove(0, 5);

                if (mensaje == "recuérdame lo que puedes hacer")
                {
                    reply = activity.CreateReply("Hola " + Environment.UserName + "\n\n" +
                                "Estoy programado para que puedas:\n" +
                            "1. Hacerme preguntas básicas como: qué fecha es hoy?, qué día es hoy?, qué hora es?, cómo te llamas?, hace cuánto naciste?, quién es tu creador?.\n" +
                            "2. Escribir la frase: recuerdame lo que puedes hacer, y yo te recordaré para qué me programaron.\n" +
                            "3. Publicar un tweet de texto en tu perfil de twitter, " +
                            "escribiendo al inicio de tu tweet la palabra: tbot.\n" +
                            "4. Publicar un tweet imagen escribe la ruta raíz de la misma y al inicio la palabra: imge.\n" +
                            "5. Traducir el texto que desees (español/inglés) escribiendo la palabra trad al inicio de tu texto\n" +
                            "6. Escribir una frase con un color en algún lugar de la misma, y trataré de adivinar cuál es el color que mencionas.");
                }
                if(mensaje.Contains("amarill"))
                {
                    reply = activity.CreateReply("Hablas del color amarillo.");
                }
                if (mensaje.Contains("purpur"))
                {
                    reply = activity.CreateReply("Hablas del color púrpura.");
                }
                if (mensaje.Contains("roj"))
                {
                    reply = activity.CreateReply("Hablas del color rojo.");
                }
                if (mensaje.Contains("azul"))
                {
                    reply = activity.CreateReply("Hablas del color azul.");
                }
                if (mensaje.Contains("verde"))
                {
                    reply = activity.CreateReply("Hablas del color verde.");
                }
                if (mensaje.Contains("rosad"))
                {
                    reply = activity.CreateReply("Hablas del color rosa.");
                }
                if (mensaje.Contains("marron"))
                {
                    reply = activity.CreateReply("Hablas del color Marrón.");
                }
                if (mensaje.Contains("cafe"))
                {
                    reply = activity.CreateReply("Hablas del color café.");
                }
                if (mensaje.Contains("negr"))
                {
                    reply = activity.CreateReply("Hablas del color negro.");
                }
                if (mensaje.Contains("blanc") || mensaje.Contains("blanqu"))
                {
                    reply = activity.CreateReply("Hablas del color blanco.");
                }
                if (mensaje == "cómo te llamas?")
                {
                    reply = activity.CreateReply("Me llamo Botti");
                }
                if (mensaje == "hace cuánto naciste?")
                {
                    reply = activity.CreateReply("Hace apenas unos días");
                }
                if (mensaje == "quién es tu creador?")
                {
                    reply = activity.CreateReply("Una estudiante aprendiendo a hacer Bot's");
                }
                if (mensaje == "qué fecha es hoy?")
                {
                    DateTime localDate = DateTime.Now;
                    var culture = new CultureInfo("en-US");
                    reply = activity.CreateReply("La fecha de hoy es: " + localDate.ToShortDateString());
                }
                if (mensaje == "qué día es hoy?")
                {
                    DateTime dia = DateTime.Today;
                    reply = activity.CreateReply("Hoy es: " + dia.ToString("dddd",
                    new CultureInfo("es-ES")) + ".");
                }
                 if (mensaje == "qué hora es?")
                {
                    DateTime hora = DateTime.Now;
                    reply = activity.CreateReply("La hora actual es: " + hora.ToString("hh:mm:ss") + ".");
                }
                if ((mensaje == "adiós") || (mensaje == "hasta luego"))
                {
                    reply = activity.CreateReply("Hasta otra ocasión " + Environment.UserName);
                }
                if (subMensaje == "tbot")
                {
                    enviarTw(tw);
                    reply = activity.CreateReply("Tweet: " + tw + " enviado.");
                }
                if(subMensaje == "imge")
                //else if(mensaje. != null)
                {
                    enviarTwM(tw);
                    reply = activity.CreateReply("Tweet media enviado.");
                }
                if(subMensaje == "trad")
                {
                    //TraslatorService = new TraslatorServie();
                    string url = String.Format("http://www.google.com/translate_t?hl=en&ie=UTF8&text={0}&langpair={1}", tw, "es/en");
                    WebClient webClient = new WebClient();
                    webClient.Encoding = System.Text.Encoding.UTF8;
                    string result = webClient.DownloadString(url);
                    result = result.Substring(result.IndexOf("<span title=\"") + "<span title=\"".Length);
                    result = result.Substring(result.IndexOf(">") + 1);
                    result = result.Substring(0, result.IndexOf("</span>"));
                    reply = activity.CreateReply(result.Trim());
                }
                if ((mensaje != "recuérdame lo que puedes hacer") && (mensaje != "cómo te llamas?") && (mensaje != "tienes sentimientos?") &&
                    (mensaje != "hace cuánto naciste?") && (mensaje != "quién es tu creador?") &&
                    (mensaje != "qué fecha es hoy?") && (subMensaje != "adiós") &&
                    (subMensaje != "hasta luego") && (subMensaje != "tbot") &&
                    (mensaje != "qué día es hoy?") && (mensaje != "qué hora es?")&&(subMensaje != "imge") &&
                    (subMensaje != "trad") && (mensaje.Contains("azul") == false) && (mensaje.Contains("amarill") == false)
                    && (mensaje.Contains("purpur") == false) && (mensaje.Contains("roj") == false)
                    && (mensaje.Contains("verde") == false) && (mensaje.Contains("rosad") == false)
                    && (mensaje.Contains("marron") == false) && (mensaje.Contains("cafe") == false)
                    && (mensaje.Contains("negr") == false) && (mensaje.Contains("blanc") == false)
                    && (mensaje.Contains("blanqu") == false))
                {
                    reply = activity.CreateReply("Lo siento, no reconozco esa palabra.");
                }

                var conector = new ConnectorClient(new Uri(activity.ServiceUrl));
                await conector.Conversations.ReplyToActivityAsync(reply);
            }
            else if (activity.Type == ActivityTypes.ConversationUpdate)
            {
                IConversationUpdateActivity update = activity;
                var client = new ConnectorClient(new Uri(activity.ServiceUrl), new MicrosoftAppCredentials());
                if (update.MembersAdded != null && update.MembersAdded.Any())
                {
                    foreach (var newMember in update.MembersAdded)
                    {
                        if (newMember.Id != activity.Recipient.Id)
                        {
                            var reply = activity.CreateReply("Hola " + Environment.UserName + "\n\n" +
                            "Estoy programado para que puedas:\n" +
                            "1. Hacerme preguntas básicas como: qué fecha es hoy?, qué día es hoy?, qué hora es?, cómo te llamas?, hace cuánto naciste?, quién es tu creador?.\n" +
                            "2. Escribir la frase: recuerdame lo que puedes hacer, y yo te recordaré para qué me programaron.\n" +
                            "3. Publicar un tweet de texto en tu perfil de twitter, " +
                            "escribiendo al inicio de tu tweet la palabra: tbot.\n" +
                            "4. Publicar un tweet imagen escribe la ruta raíz de la misma y al inicio la palabra: imge.\n" +
                            "5. Traducir el texto que desees (español/inglés) escribiendo la palabra trad al inicio de tu texto\n" +
                            "6. Escribir una frase con un color en algún lugar de la misma, y trataré de adivinar cuál es el color que mencionas.");
                            await client.Conversations.ReplyToActivityAsync(reply);
                        }
                    }
                }
                /*var connector = new ConnectorClient(new Uri(activity.ServiceUrl));
                var response = activity.CreateReply();
                response.Text = "Hola " + Environment.UserName + "\n" +
                        "Puedes hacerme preguntas básicas\n" +
                        "o publicar un tweet de texto en tu perfil de twitter, escribiendo al inicio de tu texto la palabra: tbot";
                await connector.Conversations.ReplyToActivityAsync(response);*/
            }

            return Request.CreateResponse(HttpStatusCode.OK);
        }
        private static void enviarTw(String tw)
        {
            service.SendTweet(new SendTweetOptions { Status = tw });
        }
        private static void enviarTwM(String mensaje)
        {
            int imagenid = 0;
            List<string> imagen = new List<string> { mensaje };
            //List<string> imagen = new List<string> { "C:/Users/LP/Desktop/1.jpg" };

            using (var stream = new FileStream(imagen[imagenid], FileMode.Open))
            {
                service.SendTweetWithMedia(new SendTweetWithMediaOptions
                {
                    Status = "BotMedia",
                    Images = new Dictionary<string, Stream> {
                                {
                                    imagen[imagenid], stream
                                } }
                });
            }
            //reply = activity.CreateReply(media);
        }
    }
}
